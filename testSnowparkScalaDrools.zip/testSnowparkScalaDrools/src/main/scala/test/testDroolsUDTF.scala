package test

import com.snowflake.snowpark._
import com.snowflake.snowpark.functions.{callBuiltin, col, lit}
import com.snowflake.snowpark.TableFunction

object testDroolsUDTF {

  def main(args: Array[String]): Unit = {
    val configs = Map(
      "URL" -> "https://cz40990.eu-west-2.aws.snowflakecomputing.com:443",
      "USER" -> "justin",
      "PASSWORD" -> "Google_Sep2023",
      "ROLE" -> "ACCOUNTADMIN",
      "WAREHOUSE" -> "COMPUTE_WH",
      "DB" -> "TEST_DB",
      "SCHEMA" -> "TEST_SCHEMA"
    )
    val session = Session.builder.configs(configs).create

    val mydf = readTable(session,"testTable")

    val mydf2 = mydf.withColumn("colObj", callBuiltin("object_construct", col("*")))

    mydf.show()

    mydf2.select(col("colObj")).show()

    val mydf1 = mydf.join(TableFunction("drooludtf"),mydf("id"),mydf("age"),mydf("gender"),mydf("numberOfOrders"))

    mydf1.show()

  }

  def readTable(session: Session,tblName: String): DataFrame = {

    val df = session.table(tblName)

    df
  }

}
