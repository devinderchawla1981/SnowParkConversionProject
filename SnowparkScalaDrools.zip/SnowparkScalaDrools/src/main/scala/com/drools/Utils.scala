package com.drools

object Utils {

  case class CustomerRequest(id: Integer, age: Integer, gender: String, numberOfOrders: Integer)

  case class CustomerType(customerType: String, custCatogory: Int)

}
