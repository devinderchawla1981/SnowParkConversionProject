package com.drools

import com.snowflake.snowpark.Row
import com.snowflake.snowpark.types.{IntegerType, StringType, StructField, StructType}
import com.snowflake.snowpark.udtf.UDTF4

class Demo extends UDTF4[Int, Int,String,Int]  {

  override def process(id: Int, age: Int, gender: String, numberOfOrders: Int): Iterable[Row] = {
    val response = DroolsRuleService.runAllRulesForUDF(id, age, gender, numberOfOrders)
    Iterable(Row(response.customerType, response.custCatogory))
  }


  override def endPartition() = Array.empty[Row]

  override def outputSchema(): StructType = StructType(StructField("CustomerType", StringType), StructField("CustomerCatogory", IntegerType))

}