package com.drools

import com.snowflake.snowpark._
import com.snowflake.snowpark.functions.lit
import com.drools.Demo
import com.drools.DroolsRuleService.runAllRulesForUDF
import com.drools.Utils.CustomerType

object App {
  def udfhandlerMethod(id: Integer, age: Integer, gender: String, numberOfOrders: Integer): CustomerType = {

    val response = runAllRulesForUDF(id, age, gender, numberOfOrders)

    response

  }

  def mainMethod(session: Session): Long = {
    //        //    session.addDependency("@udf_stage/drools-core-9.44.0.Final.jar")
    //        //    session.addDependency("@udf_stage/drools-compiler-9.44.0.Final.jar")
    //        //    session.addDependency("@udf_stage/kie-api-9.44.0.Final.jar")
    //        //    session.addDependency("@udf_stage/kie-internal-9.44.0.Final.jar")
    //        //    session.addDependency("@udf_stage/kie-memory-compiler-9.44.0.Final.jar")
    //        //    session.addDependency("@udf_stage/drools-util-9.44.0.Final.jar")
    //        //    session.addDependency("@udf_stage/rules/customer-category.drl")
    val tablefunction = session.udtf.registerPermanent("drooludtf", new Demo(), "@UDF_STAGE")
    session.tableFunction(tablefunction, lit(1), lit(43), lit("M"), lit(5)).count()

  }

  def main(args: Array[String]): Unit = {

    val response = udfhandlerMethod(1, 43, "M", 5)

    println(response)

  }
}
