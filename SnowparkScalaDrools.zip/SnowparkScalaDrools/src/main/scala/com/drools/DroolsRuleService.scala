package com.drools

import scala.collection.JavaConversions._
import org.kie.api.KieServices
import org.kie.api.builder.{KieBuilder, KieFileSystem, KieModule}
import org.kie.api.io.ResourceType
import org.kie.api.runtime.KieSession
import org.kie.api.runtime.rule.RuleContext
import org.kie.internal.builder.KnowledgeBuilderFactory
import org.kie.internal.io.ResourceFactory
import com.drools.Utils.{CustomerRequest, CustomerType}

object DroolsRuleService {
  val RULES_CUSTOMER_RULES_DRL = "rules/customer-category.drl"

  System.setProperty("drools.enableDynamicWiring", "true")
  val kieServices: KieServices = KieServices.Factory.get
  val kieFileSystem: KieFileSystem = kieServices.newKieFileSystem
  kieFileSystem.write(ResourceFactory.newClassPathResource(RULES_CUSTOMER_RULES_DRL))
  val kb: KieBuilder = kieServices.newKieBuilder(kieFileSystem)
  kb.buildAll
  val kieModule: KieModule = kb.getKieModule
  val kieContainer = kieServices.newKieContainer(kieModule.getReleaseId)


  def runAllRulesForUDF(id: Integer, age: Integer, gender: String, numberOfOrders: Integer): CustomerType = {
    val CustomerRequest = new CustomerRequest(id, age, gender, numberOfOrders)
    //val customerType = new CustomerType("None")
    val session = kieContainer.newKieSession()
    //session.setGlobal("customerType", customerType)
    session.insert(CustomerRequest)
    session.fireAllRules()
    val customerType =
      getResults(session, "CustomerType") match {
        case Some(x) => x.asInstanceOf[CustomerType]
        case None => null
      }
    session.dispose()
    customerType
  }

  def getResults(sess: KieSession,
                 className: String): Option[Any] = {
    val fsess = sess.getObjects().filter(o =>
      o.getClass.getName().endsWith(className))
    if (fsess.size > 0) Some(fsess.toList.head)
    else None
  }

}

object Functions {

  def insertCustomerType(kcontext: RuleContext,
                         gender: String,
                         custTypeVal: String): Unit = {

    var custC = -1

    if (gender == "M") {
      custC = 1
    } else if (gender == "F") {
      custC = 0
    } else {
      custC = -1
    }

    val sess = kcontext.getKieRuntime
      .asInstanceOf[KieSession]
    sess.insert(CustomerType(custTypeVal, custC))

  }

}